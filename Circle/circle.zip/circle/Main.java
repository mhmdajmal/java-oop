public class Main {
    public static void main(String[] args) {
        //circle a1 = new circle(5.0 , "blue");
        cylinder c1 = new cylinder(20.0 );

        System.out.println(c1.toString());
    }
}
